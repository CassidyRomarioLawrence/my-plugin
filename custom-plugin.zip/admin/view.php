<?php

echo "Use plugin to protect your site against malicious attacks";